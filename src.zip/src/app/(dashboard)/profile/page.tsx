import { ProfilePage } from "@/features/profile/profile-page";

export default function Profile() {
  return <ProfilePage />;
}
